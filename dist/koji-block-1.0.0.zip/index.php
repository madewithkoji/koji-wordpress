<?php

/**
 * Plugin Name:       Koji Block - Embed Block for Koji Apps
 * Plugin URI:        https://withkoji.com/
 * Description:       Easily embed Koji Apps in Wordpress posts. Supercharge your posts with e-commerce apps, games, and other types of powerful interactive posts.
 * Version:           1.0.0
 */

require __DIR__ . '/init.php';